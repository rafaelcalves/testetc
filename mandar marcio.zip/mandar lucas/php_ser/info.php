<html>
<head>
<title>
Local index page
</title>
</head>
<body>
<?php phpinfo(); ?>
</body>
</html>